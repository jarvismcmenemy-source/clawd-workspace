// AI Readiness Assessment Questions and Logic
const questions = [
    {
        id: 1,
        question: "How would you describe your organization's current AI strategy?",
        category: "strategy",
        options: [
            { text: "We have a comprehensive AI strategy with clear goals and roadmap", score: 4 },
            { text: "We have some AI initiatives but no formal strategy", score: 3 },
            { text: "We're exploring AI but haven't developed a strategy yet", score: 2 },
            { text: "We haven't started thinking about AI strategy", score: 1 }
        ]
    },
    {
        id: 2,
        question: "What is the current state of your data infrastructure?",
        category: "data",
        options: [
            { text: "We have clean, organized data with robust governance and easy access", score: 4 },
            { text: "Our data is mostly organized but could use better governance", score: 3 },
            { text: "Our data exists but is scattered across different systems", score: 2 },
            { text: "Our data is largely unorganized and difficult to access", score: 1 }
        ]
    },
    {
        id: 3,
        question: "How does your leadership team view AI implementation?",
        category: "leadership",
        options: [
            { text: "Fully committed with allocated budget and resources", score: 4 },
            { text: "Supportive but cautious about investment", score: 3 },
            { text: "Interested but unsure about the business case", score: 2 },
            { text: "Skeptical or uninformed about AI benefits", score: 1 }
        ]
    },
    {
        id: 4,
        question: "What is your team's current AI and technical expertise level?",
        category: "skills",
        options: [
            { text: "We have dedicated AI/ML experts and data scientists", score: 4 },
            { text: "Some team members have AI knowledge but need development", score: 3 },
            { text: "Limited AI knowledge, mostly at the awareness level", score: 2 },
            { text: "Little to no AI expertise within the organization", score: 1 }
        ]
    },
    {
        id: 5,
        question: "How well-defined are your business processes?",
        category: "processes",
        options: [
            { text: "Highly documented and optimized processes ready for AI enhancement", score: 4 },
            { text: "Most processes are documented with some optimization opportunities", score: 3 },
            { text: "Basic process documentation exists but needs improvement", score: 2 },
            { text: "Processes are mostly ad-hoc without formal documentation", score: 1 }
        ]
    },
    {
        id: 6,
        question: "What is your organization's risk tolerance for AI adoption?",
        category: "culture",
        options: [
            { text: "High - we're willing to be early adopters and experiment", score: 4 },
            { text: "Moderate - we'll adopt proven AI solutions carefully", score: 3 },
            { text: "Low - we prefer to wait and see results from others", score: 2 },
            { text: "Very low - we're very cautious about new technology", score: 1 }
        ]
    },
    {
        id: 7,
        question: "How would you rate your current technology infrastructure?",
        category: "technology",
        options: [
            { text: "Modern, cloud-based, and scalable infrastructure", score: 4 },
            { text: "Good infrastructure with some cloud adoption", score: 3 },
            { text: "Mixed infrastructure, partly modern and partly legacy", score: 2 },
            { text: "Mostly legacy systems with limited scalability", score: 1 }
        ]
    },
    {
        id: 8,
        question: "What specific business challenges are you hoping AI will solve?",
        category: "objectives",
        options: [
            { text: "We have clearly identified use cases with measurable success criteria", score: 4 },
            { text: "We have some ideas but need help defining specific use cases", score: 3 },
            { text: "We know AI could help but aren't sure exactly how", score: 2 },
            { text: "We're not sure what problems AI could solve for us", score: 1 }
        ]
    },
    {
        id: 9,
        question: "How do you currently measure business performance and success?",
        category: "metrics",
        options: [
            { text: "Comprehensive KPIs and metrics across all business functions", score: 4 },
            { text: "Good metrics for key areas with some gaps", score: 3 },
            { text: "Basic metrics but could be more comprehensive", score: 2 },
            { text: "Limited or ad-hoc performance measurement", score: 1 }
        ]
    },
    {
        id: 10,
        question: "What is your timeline expectation for AI implementation?",
        category: "timeline",
        options: [
            { text: "We're ready to start immediately with realistic expectations", score: 4 },
            { text: "We'd like to start within 3-6 months", score: 3 },
            { text: "We're planning for 6-12 months from now", score: 2 },
            { text: "We're just exploring and have no set timeline", score: 1 }
        ]
    }
];

// Assessment state
let currentQuestion = 0;
let answers = {};
let totalScore = 0;

// DOM elements
const questionContainer = document.getElementById('questionContainer');
const progressBar = document.getElementById('progress');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const assessment = document.getElementById('assessment');
const results = document.getElementById('results');
const resultTitle = document.getElementById('resultTitle');
const resultDescription = document.getElementById('resultDescription');
const scoreBreakdown = document.getElementById('scoreBreakdown');
const leadForm = document.getElementById('leadForm');

// Initialize assessment
function initializeAssessment() {
    displayQuestion(currentQuestion);
    updateProgress();
    updateNavButtons();
}

// Display current question
function displayQuestion(index) {
    const question = questions[index];
    
    questionContainer.innerHTML = `
        <div class="question active">
            <h3>${question.question}</h3>
            <div class="options" id="options-${question.id}">
                ${question.options.map((option, optIndex) => `
                    <div class="option" data-score="${option.score}" data-option="${optIndex}">
                        ${option.text}
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    // Add click listeners to options
    const options = document.querySelectorAll(`#options-${question.id} .option`);
    options.forEach(option => {
        option.addEventListener('click', () => selectOption(question.id, option));
    });

    // Restore previous selection if exists
    if (answers[question.id] !== undefined) {
        const selectedIndex = answers[question.id].optionIndex;
        options[selectedIndex].classList.add('selected');
    }
}

// Handle option selection
function selectOption(questionId, selectedOption) {
    // Remove previous selection
    const options = selectedOption.parentNode.querySelectorAll('.option');
    options.forEach(opt => opt.classList.remove('selected'));
    
    // Add selection to clicked option
    selectedOption.classList.add('selected');
    
    // Store answer
    answers[questionId] = {
        score: parseInt(selectedOption.getAttribute('data-score')),
        optionIndex: parseInt(selectedOption.getAttribute('data-option')),
        text: selectedOption.textContent
    };
    
    updateNavButtons();
}

// Update progress bar
function updateProgress() {
    const progress = ((currentQuestion + 1) / questions.length) * 100;
    progressBar.style.width = `${progress}%`;
}

// Update navigation buttons
function updateNavButtons() {
    prevBtn.disabled = currentQuestion === 0;
    
    if (currentQuestion === questions.length - 1) {
        nextBtn.textContent = answers[questions[currentQuestion].id] ? 'View Results' : 'Select an answer';
        nextBtn.disabled = !answers[questions[currentQuestion].id];
    } else {
        nextBtn.textContent = 'Next';
        nextBtn.disabled = !answers[questions[currentQuestion].id];
    }
}

// Navigate to previous question
function previousQuestion() {
    if (currentQuestion > 0) {
        currentQuestion--;
        displayQuestion(currentQuestion);
        updateProgress();
        updateNavButtons();
    }
}

// Navigate to next question or show results
function nextQuestion() {
    if (currentQuestion < questions.length - 1) {
        currentQuestion++;
        displayQuestion(currentQuestion);
        updateProgress();
        updateNavButtons();
    } else {
        showResults();
    }
}

// Calculate and display results
function showResults() {
    // Calculate scores by category
    const categoryScores = {};
    const categoryMaxScores = {};
    
    questions.forEach(q => {
        if (!categoryScores[q.category]) {
            categoryScores[q.category] = 0;
            categoryMaxScores[q.category] = 0;
        }
        if (answers[q.id]) {
            categoryScores[q.category] += answers[q.id].score;
        }
        categoryMaxScores[q.category] += 4; // Max score per question
    });

    // Calculate total score
    totalScore = Object.values(answers).reduce((sum, answer) => sum + answer.score, 0);
    const maxTotalScore = questions.length * 4;
    const percentage = Math.round((totalScore / maxTotalScore) * 100);

    // Determine readiness level
    let readinessLevel, description, recommendations;
    
    if (percentage >= 80) {
        readinessLevel = "AI-Ready Champion";
        description = "Congratulations! Your organization is well-positioned for AI implementation. You have strong leadership support, good data infrastructure, and clear objectives.";
        recommendations = "You're ready for advanced AI initiatives. Focus on pilot programs in high-impact areas and consider building internal AI capabilities.";
    } else if (percentage >= 60) {
        readinessLevel = "AI-Ready with Some Gaps";
        description = "Your organization has good AI readiness fundamentals but could benefit from addressing some key gaps before full implementation.";
        recommendations = "Focus on strengthening your data infrastructure and developing internal AI expertise. Start with low-risk pilot projects to build confidence.";
    } else if (percentage >= 40) {
        readinessLevel = "Getting AI-Ready";
        description = "Your organization is in the early stages of AI readiness. You have some foundational elements but need development in several key areas.";
        recommendations = "Develop your AI strategy, improve data governance, and invest in team training. Consider starting with AI tools that require minimal technical expertise.";
    } else {
        readinessLevel = "AI Readiness Building Phase";
        description = "Your organization is at the beginning of the AI readiness journey. This is actually a great position - you can build AI readiness the right way from the start.";
        recommendations = "Focus on education, strategy development, and data organization. Consider bringing in external expertise to accelerate your AI readiness journey.";
    }

    // Display results
    assessment.classList.add('hidden');
    results.classList.remove('hidden');
    
    resultTitle.textContent = readinessLevel;
    resultDescription.innerHTML = `
        <p><strong>Your AI Readiness Score: ${percentage}%</strong></p>
        <p>${description}</p>
        <br>
        <p><strong>Next Steps:</strong></p>
        <p>${recommendations}</p>
    `;

    // Display category breakdown
    const categoryNames = {
        strategy: 'AI Strategy',
        data: 'Data Infrastructure',
        leadership: 'Leadership Support',
        skills: 'Team Expertise',
        processes: 'Process Maturity',
        culture: 'Innovation Culture',
        technology: 'Technology Infrastructure',
        objectives: 'Clear Objectives',
        metrics: 'Performance Metrics',
        timeline: 'Implementation Timeline'
    };

    scoreBreakdown.innerHTML = `
        <h4>Detailed Breakdown</h4>
        ${Object.entries(categoryScores).map(([category, score]) => {
            const maxScore = categoryMaxScores[category];
            const categoryPercentage = Math.round((score / maxScore) * 100);
            return `
                <div class="score-item">
                    <span class="score-label">${categoryNames[category]}</span>
                    <span class="score-value">${categoryPercentage}%</span>
                </div>
            `;
        }).join('')}
        <div class="score-item" style="border-top: 2px solid #667eea; padding-top: 1rem; margin-top: 1rem;">
            <span class="score-label"><strong>Overall AI Readiness</strong></span>
            <span class="score-value"><strong>${percentage}%</strong></span>
        </div>
    `;
}

// Handle lead form submission
function handleLeadSubmission(e) {
    e.preventDefault();
    
    const formData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        company: document.getElementById('company').value,
        companySize: document.getElementById('companySize').value,
        industry: document.getElementById('industry').value,
        score: totalScore,
        percentage: Math.round((totalScore / (questions.length * 4)) * 100),
        answers: answers,
        timestamp: new Date().toISOString()
    };
    
    // Here you would normally send the data to your backend
    console.log('Lead captured:', formData);
    
    // For now, show a success message
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Thank you! We\'ll be in touch soon.';
    submitBtn.disabled = true;
    
    // You could integrate with a service like Zapier, Airtable, or a custom backend here
    // Example: 
    // fetch('your-webhook-url', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify(formData)
    // });
}

// Event listeners
document.addEventListener('DOMContentLoaded', initializeAssessment);
prevBtn.addEventListener('click', previousQuestion);
nextBtn.addEventListener('click', nextQuestion);
leadForm.addEventListener('submit', handleLeadSubmission);

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft' && !prevBtn.disabled) {
        previousQuestion();
    } else if (e.key === 'ArrowRight' && !nextBtn.disabled) {
        nextQuestion();
    }
});